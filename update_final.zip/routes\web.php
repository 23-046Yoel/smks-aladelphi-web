<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', [App\Http\Controllers\SystemController::class, 'index'])->name('home');

Route::get('/tentang/visi-misi', function () {
    return view('about.visi-misi');
})->name('about.visi-misi');

// Authentication Routes
Route::get('/login', [App\Http\Controllers\AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [App\Http\Controllers\AuthController::class, 'login']);

// Google Auth Routes
Route::get('/auth/google', [App\Http\Controllers\GoogleLoginController::class, 'redirectToGoogle'])->name('google.login');
Route::get('/auth/google/callback', [App\Http\Controllers\GoogleLoginController::class, 'handleGoogleCallback']);

// SPMB Online Routes
Route::get('/spmb', [App\Http\Controllers\SpmbController::class, 'index'])->name('spmb.index');
Route::get('/spmb/daftar', [App\Http\Controllers\SpmbController::class, 'create'])->name('spmb.create');
Route::post('/spmb/daftar', [App\Http\Controllers\SpmbController::class, 'store'])->name('spmb.store');

// Admin Dashboard Routes
Route::get('/admin/dashboard', [App\Http\Controllers\AuthController::class, 'adminDashboard'])->name('admin.dashboard');

// Kepegawaian (HR) Routes
Route::get('/kepegawaian', [App\Http\Controllers\EmployeeController::class, 'index'])->name('kepegawaian.index');

// Sistem Informasi Terpadu Routes
Route::prefix('sistem')->group(function () {
    Route::get('/ppdb', [App\Http\Controllers\SystemController::class, 'ppdb'])->name('sistem.ppdb');
    Route::get('/akademik', [App\Http\Controllers\SystemController::class, 'akademik'])->name('sistem.akademik');
    Route::get('/keuangan', [App\Http\Controllers\SystemController::class, 'keuangan'])->name('sistem.keuangan');
    Route::get('/hrd', [App\Http\Controllers\SystemController::class, 'hrd'])->name('sistem.hrd');
    Route::get('/inventaris', [App\Http\Controllers\SystemController::class, 'inventaris'])->name('sistem.inventaris');
});

// Cek SPP Publik
Route::get('/cek-spp', [App\Http\Controllers\FinanceController::class, 'publicCekSpp'])->name('public.cek-spp');

// Public Post API & Details
Route::get('/api/posts', [App\Http\Controllers\PostController::class, 'getByCategory']);
Route::get('/berita/{post}', [App\Http\Controllers\PostController::class, 'show'])->name('posts.show');

// Registration Routes
Route::get('/daftar', [App\Http\Controllers\SystemController::class, 'registration'])->name('daftar');

// Admin Management Routes
Route::prefix('admin')->group(function () {
    // Keuangan & SPP
    Route::get('/finance', [App\Http\Controllers\FinanceController::class, 'adminIndex'])->name('admin.finance.index');
    Route::post('/finance', [App\Http\Controllers\FinanceController::class, 'store'])->name('admin.finance.store');
    Route::get('/spp', [App\Http\Controllers\FinanceController::class, 'adminSppIndex'])->name('admin.spp.index');
    Route::post('/spp/student', [App\Http\Controllers\FinanceController::class, 'storeStudent'])->name('admin.spp.student.store');
    Route::post('/spp/pay', [App\Http\Controllers\FinanceController::class, 'storeSpp'])->name('admin.spp.store');
    // Posts
    Route::get('/posts', [App\Http\Controllers\PostController::class, 'adminIndex'])->name('admin.posts.index');
    Route::get('/posts/create', [App\Http\Controllers\PostController::class, 'create'])->name('admin.posts.create');
    Route::post('/posts', [App\Http\Controllers\PostController::class, 'store'])->name('admin.posts.store');
    Route::delete('/posts/{post}', [App\Http\Controllers\PostController::class, 'destroy'])->name('admin.posts.destroy');
    
    // Registrations (SPMB)
    Route::get('/registrations', [App\Http\Controllers\SpmbController::class, 'adminIndex'])->name('admin.registrations.index');
    Route::post('/registrations/{registration}/status', [App\Http\Controllers\SpmbController::class, 'updateStatus'])->name('admin.registrations.status');

    // Employees (HR)
    Route::get('/employees', [App\Http\Controllers\EmployeeController::class, 'adminIndex'])->name('admin.employees.index');
    Route::get('/employees/create', [App\Http\Controllers\EmployeeController::class, 'create'])->name('admin.employees.create');
    Route::post('/employees', [App\Http\Controllers\EmployeeController::class, 'store'])->name('admin.employees.store');
    Route::get('/employees/{employee}/edit', [App\Http\Controllers\EmployeeController::class, 'edit'])->name('admin.employees.edit');
    Route::put('/employees/{employee}', [App\Http\Controllers\EmployeeController::class, 'update'])->name('admin.employees.update');
    Route::delete('/employees/{employee}', [App\Http\Controllers\EmployeeController::class, 'destroy'])->name('admin.employees.destroy');

    // Inventory
    Route::get('/inventory', [App\Http\Controllers\InventoryController::class, 'adminIndex'])->name('admin.inventory.index');
    Route::get('/inventory/create', [App\Http\Controllers\InventoryController::class, 'create'])->name('admin.inventory.create');
    Route::post('/inventory', [App\Http\Controllers\InventoryController::class, 'store'])->name('admin.inventory.store');
    Route::get('/inventory/{inventory}/edit', [App\Http\Controllers\InventoryController::class, 'edit'])->name('admin.inventory.edit');
    Route::put('/inventory/{inventory}', [App\Http\Controllers\InventoryController::class, 'update'])->name('admin.inventory.update');
    Route::delete('/inventory/{inventory}', [App\Http\Controllers\InventoryController::class, 'destroy'])->name('admin.inventory.destroy');

    // Attendance
    Route::get('/attendance', [App\Http\Controllers\AttendanceController::class, 'index'])->name('admin.attendance.index');
    Route::get('/attendance/{subject_id}/detail', [App\Http\Controllers\AttendanceController::class, 'detail'])->name('admin.attendance.detail');
    Route::get('/attendance/{subject_id}/qr/{meeting}', [App\Http\Controllers\AttendanceController::class, 'showQr'])->name('admin.attendance.qr');
    Route::post('/attendance/{subject_id}/set-president', [App\Http\Controllers\AttendanceController::class, 'setPresident'])->name('admin.attendance.set-president');
});

// Public Inventory Route
Route::get('/inventaris', [App\Http\Controllers\InventoryController::class, 'index'])->name('inventaris.index');

// Public Attendance Scan Routes (using query param ?t= to avoid LiteSpeed URL truncation)
Route::get('/pindai/absen', [App\Http\Controllers\AttendanceController::class, 'scanForm'])->name('attendance.scan');
Route::post('/pindai/absen', [App\Http\Controllers\AttendanceController::class, 'submitScan'])->name('attendance.submit');

// Route untuk Clear Cache dari Browser (Penting untuk hosting online)
Route::get('/clear-cache', function() {
    Artisan::call('route:clear');
    Artisan::call('config:clear');
    Artisan::call('cache:clear');
    Artisan::call('view:clear');
    return 'Cache berhasil dibersihkan! Silakan coba scan ulang QR Codenya.';
});

// Route untuk Menjalankan Database Migration di Hosting
Route::get('/run-migrate', function() {
    Artisan::call('migrate', ['--force' => true]);
    return 'Database berhasil di-migrate! (Kolom baru sudah ditambahkan).';
});
